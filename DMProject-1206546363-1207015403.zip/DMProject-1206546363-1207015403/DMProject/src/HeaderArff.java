





//import org.apache.commons.io.FileUtils;

public class HeaderArff {

	public static void main(String args[])
	{
		
		System.out.print("@relation training@attribute"+" ");
	for(int i=1; i<26365;i++)
	{
		
	System.out.print("'Feature"+" "+i+"'"+" "+"numeric@attribute" +" ");
	}
	
	System.out.print("'Class Label' {1,-1}@data");
	
}
	}
