import java.io.File;
import java.io.IOException;


import java.util.ArrayList;


import java.util.List;



import org.apache.commons.io.FileUtils;

public class DataToMatrix {


	public static void main(String[] args) throws IOException {


		Double values[][] = new Double[1842][26364];


		List<String> trainingData = FileUtils.readLines(new File("InputFiles/training.txt"));


		List<String> trainingLabels = FileUtils.readLines(new File("InputFiles/label_training.txt"));



		for (int i = 0; i < trainingData.size(); i++) {


			String line = trainingData.get(i);


			String[] rowValues = line.split(" ");


			Integer rowindex = Integer.parseInt(rowValues[0]);
			Integer featureIndex = Integer.parseInt(rowValues[1]);
			Double featureValue = Double.parseDouble(rowValues[2]);
			values[rowindex-1][featureIndex-1]=featureValue;


		}
		


		List<String> rows = new ArrayList<String>();


		for (int i = 0; i < values.length; i++) 
		{


			String text = "";
			

			for (int j = 0; j < values[i].length; j++) 
			{

				/*if(i==0 && j==0)
				System.out.print("Information Id");
				if(i==0 && j>0)
				System.out.print("Feature id"+j);
				
				
			
				if(i>0 && j>0)
*/				{
					if(values[i][j]==null)


					values[i][j]=0.0;

				text+=values[i][j]+", ";
				}

			}
			
			//if(values.length%50==0)
			System.out.println(i+" values written....");

			

			text+=trainingLabels.get(i);


			rows.add(text);


		}
		FileUtils.writeLines(new File("InputFiles/trainingMatrix2.txt"), rows);


	}
}



 



 